<?php

include_once('./CRUD/connection.php');


$sql = "SELECT * FROM dropdown_data WHERE expiration_date <= DATE_ADD(CURDATE(), INTERVAL 15 DAY)";
$result = $conn->query($sql);


if ($result && $result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

        $dropdownItem = '<a href="#" class="dropdown-item">' . $row['message'] . '</a>';
       
        echo $dropdownItem;
    }
} else {

    echo '<a href="#" class="dropdown-item">No alerts found.</a>';
}

$conn->close();
?>
