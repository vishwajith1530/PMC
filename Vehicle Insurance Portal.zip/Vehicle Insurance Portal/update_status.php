<?php
include_once('./CRUD/connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $recordId = $_POST['id'];
    $selectedAction = $_POST['status'];

    $renewedFlag = ($selectedAction == 'Renewed') ? 1 : 0;
    $updateRenewedFlagSql = "UPDATE vehicle_data SET Renewed_Flag = $renewedFlag WHERE Id = $recordId";

    $updateInsuranceDueSql = "";
    if ($selectedAction == 'Renewed') {
        $newExpiryDate = $_POST['newExpiryDate']; 
        $updateInsuranceDueSql = "UPDATE vehicle_data SET Insurance_Due = '$newExpiryDate' WHERE Id = $recordId";
    }

    $success = true;
    $errorMessage = "";

    if ($conn->query($updateRenewedFlagSql) !== TRUE) {
        $success = false;
        $errorMessage = $conn->error;
    }

    if (!empty($updateInsuranceDueSql) && $conn->query($updateInsuranceDueSql) !== TRUE) {
        $success = false;
        $errorMessage = $conn->error;
    }

    if ($success) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $errorMessage]);
    }

    $conn->close();
}
?>
