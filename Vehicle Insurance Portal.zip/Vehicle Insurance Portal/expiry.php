<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta Registration_No="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expiry Alerts / Ensuare</title>

    <link rel="shortcut icon" href="./favicon.svg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="./CRUD/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./CRUD/datatable/dataTable.bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/admin.css">
    <style>
        .height10 {
            height: 10px;
        }

        .mtop10 {
            margin-top: 10px;
        }

        .modal-label {
            position: relative;
            top: 7px;
        }

        table,
        th,
        td {
            background-color: white;
        }

        .table-box {
            background-color: #fff;
            border: 1px solid #808080;
            border-radius: 5px;
            padding: 40px;
            border-width: 2px;
        }
        .main-container .navcontainer .nav h4 a {
            color: #000000;
            text-decoration: none;
        }

    </style>
</head>

<body>
    <header>
        <div class="logosec">
            <img src="assets/images/logo.png" class="nav-img larger-logo" alt="dashboard"
                style="width: 70px; margin-top: 5px ; height: 50px;">
            <div class="logo" style="font-weight: bold;">Ensuare</div>
            <img src="assets/images/menu.png" class="icn menuicn" id="menuicn" alt="menu-icon">
        </div>


        <div class="message">
            <div class="circle"></div>
            <img src="assets/images/notification.png" class="icn" alt="" id="notification">
            <div class="dp">
                <img src="https://shorturl.at/vIMV0" class="dpicn" alt="dp">
            </div>
        </div>
    </header>

    <div class="main-container">
        <div class="navcontainer">
            <nav class="nav">
                <div class="nav-upper-options">
                    <div class="nav-option option">
                        <img src="assets/images/dashboard.png" class="nav-img" alt="articles">
                        <h4><a href="admin.php">Dashboard</a></h4>
                    </div>

                    <div class="option2 nav-option">
                        <img src="assets/images/alert.png" class="nav-img" alt="articles">
                        <h4><a href="expiry.php">Expiry Alerts</a></h4>
                    </div>

                    <div class="nav-option option3">
                        <img src="assets/images/list.png" class="nav-img" alt="report">
                        <h4><a href="export.php">Export List</a></h4>
                    </div>

                    <div class="nav-option logout">
                        <img src="assets/images/logout.png" class="nav-img" alt="logout">
                        <h4><a href="">Logout</a></h4>
                    </div>
                </div>
            </nav>
        </div>
        <div class="main">

        <div class="box-container">
			<div class="box box1">
    			<div class="text">
       				 <?php
        				include_once('./CRUD/connection.php');
        				$sql = "SELECT COUNT(Id) AS count FROM vehicle_data";
        				$result = $conn->query($sql);
       					 if ($result && $result->num_rows > 0) {
            				$row = $result->fetch_assoc();
            				$count = $row['count'];
       					 } else {
            				$count = 0;
        				 }
        			 ?>
        			<h2 class="topic-heading"><?php echo $count; ?></h2>
        			<h2 class="topic">Total Number<br>of Vehicles</h2>
    			</div>
    			<img src="assets/images/insurance.png" alt="Views">
				</div>	

				<div class="box box2">
				<div class="text">
					<?php
					include_once('./CRUD/connection.php');

					function expDate($Fitness_Due) {
						$dateObj = new DateTime($Fitness_Due);
						$currentDateObj = new DateTime();
						$diff = $dateObj->diff($currentDateObj);
						return $diff->days;
					}

					$sql = "SELECT * FROM vehicle_data";
					$query = $conn->query($sql);
					$count = 0;

					while ($row = $query->fetch_assoc()) {
						$daysDiff = expDate($row['Fitness_Due']);
						if ($daysDiff <= 15) {
							$count++;
						}
					}
					?>
					<h2 class="topic-heading"><?php echo $count; ?></h2>
					<h2 class="topic">Fitness<br>Expiry Dates</h2>
				</div>
				<img src="assets/images/Expiry.png" alt="Views">
				</div>

				<div class="box box3">
				<div class="text">
				<?php
				include_once('./CRUD/connection.php');

				function expDate2($PUC_Due) {
					$dateObj = new DateTime($PUC_Due);
					$currentDateObj = new DateTime();
					$diff = $dateObj->diff($currentDateObj);
					return $diff->days;
				}

				$sql = "SELECT * FROM vehicle_data";
				$query = $conn->query($sql);
				$count = 0;

				while ($row = $query->fetch_assoc()) {
					$daysDiff = expDate($row['PUC_Due']);
					if ($daysDiff <= 15) {
						$count++;
					}
				}
				?>
				<h2 class="topic-heading"><?php echo $count; ?></h2>
				<h2 class="topic">PUC<br>Expiry Dates</h2>
				</div>
				<img src="assets/images/Expiry.png" alt="Views">
				</div>	


				<div class="box box4">
				<div class="text">
				<?php
				include_once('./CRUD/connection.php');
				function expDate3($Insurance_Due) {
					$dateObj = new DateTime($Insurance_Due);
					$currentDateObj = new DateTime();
					$diff = $dateObj->diff($currentDateObj);
					return $diff->days;
				}

				$sql = "SELECT * FROM vehicle_data";
				$query = $conn->query($sql);
				$count = 0;

				while ($row = $query->fetch_assoc()) {
					$daysDiff = expDate($row['Insurance_Due']);
					if ($daysDiff <= 15) {
						$count++;
					}
				}
				?>
				<h2 class="topic-heading"><?php echo $count; ?></h2>
				<h2 class="topic">Insurance<br>Expiry Dates</h2>
				</div>
				<img src="assets/images/Expiry.png" alt="Views">
				</div>
				</div>

            <div class="row" style="margin-top: 100px">
                <?php
                if (isset($_SESSION['error'])) {
                    echo '
                    <div class="alert alert-danger text-center">
                        <button class="close">&times;</button>
                        ' . $_SESSION['error'] . '
                    </div>
                    ';
                    unset($_SESSION['error']);
                }
                if (isset($_SESSION['success'])) {
                    echo '
                    <div class="alert alert-success text-center">
                        <button class="close">&times;</button>
                        ' . $_SESSION['success'] . '
                    </div>
                    ';
                    unset($_SESSION['success']);
                }
                ?>
            </div>
            <div class="table-box">
                <div class="row">
                    <a href="?alert_users" data-toggle="modal" class="btn btn-primary" style="background-color: #088F8F ; 
                    border-color: #088F8F"><span class="glyphicon glyphicon-alert"></span> Alert Users</a>
                    <a href="" class="btn btn-success pull-right" id="download-pdf"><span class="glyphicon glyphicon-print"></span>
                        Download PDF</a>
                </div>

                <br><br>

                <div class="height10"></div>
                <div class="row">
                    <table id="myTable" class="table table-bordered table-striped">
                        <thead>
                            <th>ID</th>
                            <th>Registration_No</th>
                            <th>Vehicle_Class</th>
                            <th>Body_Type</th>
                        </thead>
                        <tbody>
                        <?php
                            include_once('./CRUD/connection.php');

                            function dateDiffInDays($dueDate, $currentDate) {
                                $diff = $dueDate - $currentDate;
                                return floor($diff / (60 * 60 * 24));
                            }

                            $sql = "SELECT * FROM vehicle_data";
                            $query = $conn->query($sql);

                            while ($row = $query->fetch_assoc()) {
                                $insuranceDueDate = strtotime($row['Insurance_Due']);
                                $currentDate = time();

                                $daysDiff = dateDiffInDays($insuranceDueDate, $currentDate);

                                echo "<tr>
                                    <td>" . $row['Id'] . "</td>
                                    <td style='color:#ff5349; font-weight:bold'>" . $row['Registration_No'] . "</td>
                                    <td style='color:#ff5349; font-weight:bold'>" . $row['Vehicle_Class'] . "</td>
                                    <td style='color:#ff5349; font-weight:bold'>" . $row['Body_Type'] . " </td>
                                    <td>
                                        <a href='#delete_" . $row['Id'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
                                    </td>
                                </tr>";

                                if ($daysDiff <= 15) {
                                    include('./CRUD/edit_delete_modal.php');

                                    $to = 'mayureshkamble20@gmail.com';
                                    $subject = "Expiry Alert";
                                    $message = "
                                        Dear " . $row['Registration_No'] . ",
                                        Your Vehicle Insurance Policy is going to expire soon. We highly recommend renewing your policy before it expires to ensure uninterrupted coverage.
                                        Policy Details: 

                                        Registration No.: " . $row['Registration_No'] . "                                    
                                        Vehicle Class: " . $row['Vehicle_Class'] . "                                  
                                        Insurance Due: " . $row['Insurance_Due'] . "

                                        Renewing your policy is quick and easy. Simply visit our website or contact our customer service representatives for assistance.
                                        Thank you for choosing our insurance services. We value your continued support and look forward to serving you again.

                                        Best Regards,                                       
                                        Ensuare Insurance Team";

                                    $headers = "From: internshipuxo@gmail.com";

                                    mail($to, $subject, $message, $headers);
                                }
                            }                                                                      
                                ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php include('./CRUD/add_modal.php') ?>

    <script src="assets/js/admin.js"></script>
    <script src="./CRUD/jquery/jquery.min.js"></script>
    <script src="./CRUD/bootstrap/js/bootstrap.min.js"></script>
    <script src="./CRUD/datatable/jquery.dataTables.min.js"></script>
    <script src="./CRUD/datatable/dataTable.bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.68/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.68/vfs_fonts.js"></script>


<script>
    $(document).ready(function () {
    $(document).on('click', '.close', function () {
      $('.alert').hide();
    });

    $('#download-pdf').click(function (e) {
      e.preventDefault();
      var headers = [];
      $('#myTable thead th').each(function () {
        headers.push({
          text: $(this).text(),
          style: 'tableHeader'
        });
      });

      var data = [];
      $('#myTable tbody tr').each(function () {
        var row = [];
        $(this).find('td').each(function () {
          row.push($(this).text());
        });
        data.push(row);
      });

      var docDefinition = {
        content: [
          { text: 'Data of Users whose Insurance is going to Expire ', style: 'header' },
          {
            layout: 'lightHorizontalLines',
            table: {
              headerRows: 1,
              widths: ['auto', 'auto', 'auto', 'auto'],
              body: [
                headers,
                ...data
              ]
            }
          }
        ],
        styles: {
          header: {
            fontSize: 18,
            bold: true,
            margin: [0, 0, 0, 10]
          },
          tableHeader: {
            bold: true,
            fillColor: '#CCCCCC',
            alignment: 'center'
          }
        },
        pageSize: {
                width: 500, 
                height: 550
            }
      };

      pdfMake.createPdf(docDefinition).download('Expiry_data.pdf');
    });

    $('#myTable').DataTable();
  });

</script>
</body>
</html>
