<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Dashboard / Ensuare</title>

    <link rel="shortcut icon" href="./favicon.svg">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="./CRUD/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="./CRUD/datatable/dataTable.bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/admin.css">
	<style>

		.height10 {
			height: 10px;
		}

		.mtop10 {
			margin-top: 10px;
		}

		.modal-label {
			position: relative;
			top: 7px;
		}

		table, th, td {
			background-color: white;
		}

		.table-box {
			margin-top: -50px;
			background-color: #fff;
			border-radius: 5px;
			padding: 0px;
			border-width: 2px ;
		}

		.main-container .navcontainer .nav h4 a {
			color: #000000;
			text-decoration: none;
		}

		.tabs {
			height:45px;
			padding: 0 0 0 0;
			overflow:visible;
		}
		
		.tab {
			width:200px;
			height:45px;
			overflow:hidden;
			float:left;
			margin:0 -15px 0 0;
		}

		.tab-box {
			height:50px;
			background: #fff;
			border-radius: 4px;
			border:1px solid #ccc;
			margin:0 10px 0;
			box-shadow: 0 0 2px  #fff inset;
			-webkit-transform: perspective(100px) rotateX(30deg);
			-moz-transform: perspective(100px) rotateX(30deg);
		}

		.tab-box span {
			font-weight: 800;
			margin-left: 25px;
			font-size: 15px;
		}

		.tab.active {
			z-index:40;
			position:relative;
			padding-bottom:1px;
		}
		
		.tab.active .tab-box{
			color: #fff;
			background-color: #088F8F;
			box-shadow: 0 0 2px 0 #fff inset;
		}

		.content {
			z-index:1;
			padding:100px;
			border:2px solid #088F8F;
			background:#fff;
			position:relative;
		
		}

		.clear {
			clear:both;
		}

		#overlay {
			display: none;
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			background-color: rgba(0, 0, 0, 0.5);
			z-index: 999;
		}

		#actionFormPopup {
			display: none;
			position: fixed;
			top: 50%;
			left: 50%;
			transform: translate(-50%, -50%);
			background-color: white;
			padding: 20px;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
			z-index: 1000;
			width: 400px;
			max-width: 80%;
			height: 300px;
			max-height: 80%;
		}

		#actionFormPopup h3 {
			margin-bottom: 10px;
			margin-top: 20px;
		}

		#actionFormPopup .form-check {
			margin-bottom: 15px;
		}

		#actionFormPopup button {
			display: block;
			margin-top: 10px;
			padding: 8px 15px;
		}

		#closeButton {
			font-size: 2rem;
			position: absolute;
			font-weight: bold;
			top: 10px;
			right: 10px;
			cursor: pointer;
		}

		#newExpiryDateField {
			display: none;
			margin-top: 10px;
		}

	</style>

</head>

<body>
	<header>
	<div class="logosec">
  	<img src="assets/images/logo.png" class="nav-img larger-logo" alt="dashboard" style="width: 70px; margin-top: 5px ; height: 50px;">
  	<div class="logo" style="font-weight: bold;">Ensuare</div>
  	<img src="assets/images/menu.png" class="icn menuicn" id="menuicn" alt="menu-icon">
	</div>


	<div class="message">
    	<div class="circle"></div>
    	<img src="assets/images/notification.png" class="icn" alt="" id="notification">
    	<div class="dp">
        	<img src="https://shorturl.at/vIMV0" class="dpicn" alt="dp">
    	</div>
	</div>
	</header>

	<div class="main-container">
		<div class="navcontainer">
			<nav class="nav">
			<div class="nav-upper-options">
					<div class="nav-option option1">
						<img src="assets/images/dashboard.png" class="nav-img" alt="articles">
						<h4><a href="admin.php">Dashboard</a></h4>
					</div>

					<div class="option2 nav-option">
						<img src="assets/images/alert.png" class="nav-img" alt="articles">
						<h4><a href="expiry.php">Expiry Alerts</a></h4>
					</div>

					<div class="nav-option option3">
						<img src="assets/images/list.png" class="nav-img" alt="report">
						<h4><a href="">Export List</a></h4>
					</div>

					<div class="nav-option logout">
						<img src="assets/images/logout.png" class="nav-img" alt="logout">
						<h4><a href="logout.php">Logout</a></h4>
					</div>
			</nav>
		</div>

		<div class="main">

			<div class="box-container">
			<div class="box box1">
    			<div class="text">
       				 <?php
        				include_once('./CRUD/connection.php');
        				$sql = "SELECT COUNT(Id) AS count FROM vehicle_data";
        				$result = $conn->query($sql);
       					 if ($result && $result->num_rows > 0) {
            				$row = $result->fetch_assoc();
            				$count = $row['count'];
       					 } else {
            				$count = 0;
        				 }
        			 ?>
        			<h2 class="topic-heading"><?php echo $count; ?></h2>
        			<h2 class="topic">Total Number<br>of Vehicles</h2>
    			</div>
    			<img src="assets/images/insurance.png" alt="Views">
				</div>	



				<?php
				include_once('./CRUD/connection.php');

				function daysUntilExpiry($expiryDate) {
					$expiryTimestamp = strtotime($expiryDate);
					$currentTimestamp = strtotime('today');
					$diff = ($expiryTimestamp - $currentTimestamp) / (60 * 60 * 24); 
					return $diff;
				}

				$sql = "SELECT * FROM vehicle_data";
				$query = $conn->query($sql);
				$count = 0;

				while ($row = $query->fetch_assoc()) {
					$daysDiff = daysUntilExpiry($row['Fitness_Due']);
					if ($daysDiff >= 0 && $daysDiff <= 15) {
						$count++;
					}
				}

				?>

				<div class="box box2">
					<div class="text">
						<h2 class="topic-heading"><?php echo $count; ?></h2>
						<h2 class="topic">Insurance<br>Expiry Dates</h2>
					</div>
					<img src="assets/images/Expiry.png" alt="Views">
				</div>



				<?php
				include_once('./CRUD/connection.php');

				function daysUntilDue1($dueDate) {
					$dueTimestamp = strtotime($dueDate);
					$currentTimestamp = strtotime('today');
					$diff = ($dueTimestamp - $currentTimestamp) / (60 * 60 * 24); 
					return $diff;
				}

				$sql = "SELECT * FROM vehicle_data";
				$query = $conn->query($sql);
				$countPUC = 0;

				while ($row = $query->fetch_assoc()) {
					$daysDiffPUC = daysUntilDue1($row['PUC_Due']);
					if ($daysDiffPUC >= 0 && $daysDiffPUC <= 15) {
						$countPUC++;
					}
				}

				?>

				<div class="box box3">
					<div class="text">
						<h2 class="topic-heading"><?php echo $countPUC; ?></h2>
						<h2 class="topic">PUC<br>Expiry Dates</h2>
					</div>
					<img src="assets/images/Expiry.png" alt="Views">
				</div>


				<?php
				include_once('./CRUD/connection.php');

				function daysUntilExpiry2($expiryDate) {
					$expiryTimestamp = strtotime($expiryDate);
					$currentTimestamp = strtotime('today');
					$diff = ($expiryTimestamp - $currentTimestamp) / (60 * 60 * 24); 
					return $diff;
				}

				$sql = "SELECT * FROM vehicle_data";
				$query = $conn->query($sql);
				$count = 0;

				while ($row = $query->fetch_assoc()) {
					$daysDiff = daysUntilExpiry2($row['Insurance_Due']); 
					if ($daysDiff >= 0 && $daysDiff <= 15) {
						$count++;
					}
				}

				?>

				<div class="box box4">
					<div class="text">
						<h2 class="topic-heading"><?php echo $count; ?></h2>
						<h2 class="topic">Insurance<br>Expiry Dates</h2>
					</div>
					<img src="assets/images/Expiry.png" alt="Views">
				</div>

				</div>


			<br><br><br>

			<div class="row">
				<?php
				if (isset($_SESSION['error'])) {
					echo '
					<div class="alert alert-danger text-center">
						<button class="close">&times;</button>
						' . $_SESSION['error'] . '
					</div>
					';
					unset($_SESSION['error']);
				}
				if (isset($_SESSION['success'])) {
					echo '
					<div class="alert alert-success text-center">
						<button class="close">&times;</button>
						' . $_SESSION['success'] . '
					</div>
					';
					unset($_SESSION['success']);
				}
				?>
			</div style="margin-bottom:-500px">

			<div class="tabs">
				<div class="tab active" onclick="showContent('tab1')"><div class="tab-box"><span>Insurance Policy</span></div></div>
				<div class="tab" onclick="showContent('tab2')"><div class="tab-box"><span>PUC Certificate</span></div></div>
				<div class="tab" onclick="showContent('tab3')"><div class="tab-box"><span>Fitness Certificate</span></div></div>
			</div>

			<div class="content" id="content-tab1">
			<div class="table-box">

			<div class="row">
				<a href="#addnew" data-toggle="modal" class="btn btn-primary" style="background-color: #088F8F ; border-color: #088F8F"><span class="glyphicon glyphicon-plus"></span> Add User</a>
			</div>
			
			<br><br>

							<?php
								include_once('./CRUD/connection.php');

								function daysUntilDue3($dueDate) {
									$dueTimestamp = strtotime($dueDate);
									$currentTimestamp = strtotime('today');
									$diff = ($dueTimestamp - $currentTimestamp) / (60 * 60 * 24);
									return $diff;
								}

								$sql = "SELECT * FROM vehicle_data";
								$query = $conn->query($sql);

								?>

								<div class="height10"></div>
								<div class="row">
									<div class="table-responsive">
										<table id="myTable" class="table table-bordered table-striped">
											<thead>
												<tr>
													<th>ID</th>
													<th>Registration No.</th>
													<th>Vehicle Class</th>
													<th>Body Type</th>
													<th>Insurance Due</th>
													<th>Edit/Delete</th>
												</tr>
											</thead>
											<tbody>
												<?php
												while ($row = $query->fetch_assoc()) {
													$InsuranceDueDate = strtotime($row['Insurance_Due']);
													$currentDate = time();
													$daysDiff = daysUntilDue1($row['Insurance_Due']);

													$highlightStyle = ($daysDiff <= 15 && $daysDiff >= 0) ? "style='color:#ff5349; font-weight:bold'" : "";

													echo "<tr {$highlightStyle}>
														<td>" . $row['Id'] . "</td>
														<td {$highlightStyle}>" . $row['Registration_No'] . "</td>
														<td {$highlightStyle}>" . $row['Vehicle_Class'] . "</td>
														<td {$highlightStyle}>" . $row['Body_Type'] . " </td>
														<td {$highlightStyle}>" . $row['Insurance_Due'] . " </td>
														<td>
															<a href='#edit_" . $row['Id'] . "' class='btn btn-success btn-sm' data-toggle='modal'><i class='fas fa-eye'></i>  View</a>
															<a href='#delete_" . $row['Id'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
															<a href='#;' class='btn btn-primary btn-sm' onclick='toggleActionForm()'><span class='glyphicon glyphicon-share-alt'></span> Status</a>															</td>
													</tr>";

													include('./CRUD/edit_delete_modal.php');
												}
												?>

												<div id="overlay"></div>

												<div id="actionFormPopup">
													<span id="closeButton" onclick="toggleActionForm()">X</span>
													<h3>Status of the Insurance Policy:</h3><br>
													<form>
														<div class="form-check">
															<input class="form-check-input" type="radio" name="actionRadioPopup" id="renewed" value="Renewed" onclick="showNewExpiryDateField()">
															<label class="form-check-label" for="renewed">Renewed</label>
														</div>
														<div class="form-check">
															<input class="form-check-input" type="radio" name="actionRadioPopup" id="notRenewed" value="Not Renewed" onclick="hideNewExpiryDateField()">
															<label class="form-check-label" for="notRenewed">Not Renewed</label>
														</div>

														<div id="newExpiryDateField">
															<label for="newExpiryDate">New Expiry Date:</label>
															<input type="text" id="newExpiryDate" name="newExpiryDate">
														</div>

														<button type="button" class="btn btn-primary" onclick="performActionPopup()">Submit</button>
													</form>
												</div>

											</tbody>
										</table>
									</div>
								</div>
							</div>

	</div>

	<div class="content" id="content-tab2" style="display: none;">
			<div class="table-box">

			<div class="row">
				<a href="#addnew" data-toggle="modal" class="btn btn-primary" style="background-color: #088F8F ; border-color: #088F8F"><span class="glyphicon glyphicon-plus"></span> Add User</a>
			</div>
			

			<br><br>

			<div class="height10"></div>
					<div class="row">
					<div class="table-responsive">
						<table id="myTable" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>ID</th>
									<th>Registration No.</th>
									<th>Vehicle Class</th>
									<th>Body Type</th>
									<th>Edit/Delete</th>
								</tr>
							</thead>
							<tbody>
								<?php
								include_once('./CRUD/connection.php');			
								function dateDiffInDays1($PUC_Due, $currentDate) {
									$diff = $currentDate - $PUC_Due;
									return floor($diff / (60 * 60 * 24));
								}
							
								$sql = "SELECT * FROM vehicle_data";
							
								$query = $conn->query($sql);
								while ($row = $query->fetch_assoc()) {
									$Date = strtotime($row['PUC_Due']);
									$currentDate = time();
								
									$daysDiff = dateDiffInDays1($Date, $currentDate);
								
									if ($daysDiff <= 15 && $daysDiff >=0) {
										echo "<tr>
											<td>" . $row['Id'] . "</td>
											<td style='color:#ff5349 ; font-weight:bold'>" . $row['Registration_No'] . "</td>
											<td style='color:#ff5349 ; font-weight:bold'>" . $row['Vehicle_Class'] . "</td>
											<td style='color:#ff5349 ; font-weight:bold'>" . $row['Body_Type'] . " </td>
											<td>
											<a href='#edit_" . $row['Id'] . "' class='btn btn-success btn-sm' data-toggle='modal'><i class='fas fa-eye'></i>  View</a>
												<a href='#delete_" . $row['Id'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
												<a href='" . $row['Id'] . "' class='btn btn-primary btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-share-alt'></span> Action</a>
											</td>
											</tr>";
											} else {
												echo "<tr>
													<td>" . $row['Id'] . "</td>
													<td>" . $row['Registration_No'] . "</td>
													<td>" . $row['Vehicle_Class'] . "</td>
													<td>" . $row['Body_Type'] . "</td>
	
													<td>
														<a href='#edit_" . $row['Id'] . "' class='btn btn-success btn-sm' data-toggle='modal'><i class='fas fa-eye'></i>  View</a>
														<a href='#delete_" . $row['Id'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
														<a href='" . $row['Id'] . "' class='btn btn-primary btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-share-alt'></span> Action</a>
													</td>
												</tr>";
											}								
									include('./CRUD/edit_delete_modal.php');
										}
										?>
							</tbody>
						</table>
					</div>
				</div>	
			</div>
	</div>

	<div class="content" id="content-tab3" style="display: none;">
			<div class="table-box">

			<div class="row">
				<a href="#addnew" data-toggle="modal" class="btn btn-primary" style="background-color: #088F8F ; border-color: #088F8F"><span class="glyphicon glyphicon-plus"></span> Add User</a>
			</div>
			

			<br><br>

			<div class="height10"></div>
					<div class="row">
					<div class="table-responsive">
						<table id="myTable" class="table table-bordered table-striped">
							<thead>
								<tr>
									<th>ID</th>
									<th>Registration No.</th>
									<th>Vehicle Class</th>
									<th>Body Type</th>
									<th>Edit/Delete</th>
								</tr>
							</thead>
							<tbody>
								<?php
								include_once('./CRUD/connection.php');			
								function dateDiffInDays2($Fitness_Due, $currentDate) {
									$diff = $currentDate - $Fitness_Due;
									return floor($diff / (60 * 60 * 24));
								}
							
								$sql = "SELECT * FROM vehicle_data";
							
								$query = $conn->query($sql);
								while ($row = $query->fetch_assoc()) {
									$Date = strtotime($row['Fitness_Due']);
									$currentDate = time();
								
									$daysDiff = dateDiffInDays2($Date, $currentDate);
								
									if ($daysDiff <= 15 && $daysDiff >=0) {
										echo "<tr>
											<td>" . $row['Id'] . "</td>
											<td style='color:#ff5349 ; font-weight:bold'>" . $row['Registration_No'] . "</td>
											<td style='color:#ff5349 ; font-weight:bold'>" . $row['Vehicle_Class'] . "</td>
											<td style='color:#ff5349 ; font-weight:bold'>" . $row['Body_Type'] . " </td>
											<td>
											<a href='#edit_" . $row['Id'] . "' class='btn btn-success btn-sm' data-toggle='modal'><i class='fas fa-eye'></i>  View</a>
												<a href='#delete_" . $row['Id'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
												<a href='" . $row['Id'] . "' class='btn btn-primary btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-share-alt'></span> Action</a>
											</td>
											</tr>";
											} else {
												echo "<tr>
													<td>" . $row['Id'] . "</td>
													<td>" . $row['Registration_No'] . "</td>
													<td>" . $row['Vehicle_Class'] . "</td>
													<td>" . $row['Body_Type'] . "</td>
													<td>
														<a href='#edit_" . $row['Id'] . "' class='btn btn-success btn-sm' data-toggle='modal'><i class='fas fa-eye'></i>  View</a>
														<a href='#delete_" . $row['Id'] . "' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
														<a href='" . $row['Id'] . "' class='btn btn-primary btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-share-alt'></span> Action</a>
													</td>
												</tr>";
											}								
									include('./CRUD/edit_delete_modal.php');
										}
										?>
							</tbody>
						</table>
					</div>
				</div>	
			</div>
	</div>
		
	</div>

	<?php include('./CRUD/add_modal.php') ?>				

	<script src="assets/js/admin.js"></script>
	<script src="./CRUD/jquery/jquery.min.js"></script>
	<script src="./CRUD/bootstrap/js/bootstrap.min.js"></script>
	<script src="./CRUD/datatable/jquery.dataTables.min.js"></script>
	<script src="./CRUD/datatable/dataTable.bootstrap.min.js"></script>
	<script>
		$(document).ready(function () {
			$('#myTable').DataTable();
			$(document).on('click', '.close', function () {
				$('.alert').hide();
			})
		});
		function confirmLogout() {
        return confirm("Are you sure you want to logout?");
    	}

		$('.tab').click(function(){
		$('.tab').removeClass('active');
		$(this).addClass('active');
		});

		function showContent(tabId) {
		document.querySelectorAll('.content').forEach(function (content) {
			content.style.display = 'none';
			$('#myTable', content).DataTable().destroy(); 
		});

		document.querySelectorAll('.tab').forEach(function (tab) {
			tab.classList.remove('active');
		});

		document.getElementById('content-' + tabId).style.display = 'block';
		document.querySelector('.tab[data-tab="' + tabId + '"]').classList.add('active');

		$('#myTable', document.getElementById('content-' + tabId)).DataTable(); 
	}

    function toggleActionForm() {
        var overlay = document.getElementById('overlay');
        var form = document.getElementById('actionFormPopup');

        overlay.style.display = overlay.style.display === 'none' ? 'block' : 'none';
        form.style.display = form.style.display === 'none' ? 'block' : 'none';
    }

    function showNewExpiryDateField() {
        document.getElementById('newExpiryDateField').style.display = 'block';
    }

    function hideNewExpiryDateField() {
        document.getElementById('newExpiryDateField').style.display = 'none';
    }

    function performActionPopup() {
        var selectedAction = document.querySelector('input[name="actionRadioPopup"]:checked');
        if (selectedAction) {
            alert('Policy Status Updated : ' + selectedAction.value);
        } else {
            alert('Please select an action.');
        }
        toggleActionForm();
    }

	$(document).ready(function () {

	$('.btn-success').on('click', function () {
		var recordId = $(this).data('id'); 
		var selectedAction = $('input[name="status"]:checked').val();
		var newExpiryDate = $('#newExpiryDate').val();

		console.log("Submitting AJAX request with data:", {
			id: recordId,
			status: selectedAction,
			newExpiryDate: newExpiryDate
		});

		$.ajax({
		});

		$.ajax({
			type: 'POST',
			url: 'update_status.php',
			data: {
				id: recordId,
				status: selectedAction,
				newExpiryDate: newExpiryDate
			},
			dataType: 'json',
			success: function (response) {
				if (response.success) {
					console.log('Status updated successfully');
				} else {
					console.error('Error updating status: ' + response.error);
				}
			},
			error: function (error) {
				console.error('AJAX error: ' + JSON.stringify(error));
			}
		});
	});
	});
	</script>
</body>

</html>