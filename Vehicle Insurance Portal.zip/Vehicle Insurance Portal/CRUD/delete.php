<?php
	session_start();
	include_once('connection.php');

	if(isset($_GET['Id'])){
		$sql = "DELETE FROM vehicle_data WHERE Id = '".$_GET['Id']."'";


		if($conn->query($sql)){
			$_SESSION['success'] = 'User deleted successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong while deleting a User';
		}
	}
	else{
		$_SESSION['error'] = 'Select a User to be deleted ';
	}

	header('location: admin.php');
?>