<?php
	session_start();
	include_once('connection.php');

	if(isset($_POST['add'])){
		$Name = $_POST['Registration_No'];
		$Vehicle_Class = $_POST['Vehicle_Class'];
		$Body_Type = $_POST['Body_Type'];
		$Manufacturer = $_POST['Manufacturer'];
		$Registration_Due = $_POST['Registration_Due'];
		$Insurance_Due = $_POST['Insurance_Due'];
		$Tax_Validity = $_POST['Tax_Validity'];
		$Fitness_Due = $_POST['Fitness_Due'];
		$PUC_Due = $_POST['PUC_Due'];
		$sql = "INSERT INTO vehicle_data (Name, Vehicle_Class, Body_Type, Manufacturer, Registration_Due, Insurance_Due, Tax_Validity, Fitness_Due, PUC_Due) VALUES ('$Name', '$Vehicle_Class', '$Body_Type', '$Manufacturer', '$Registration_Due', '$Insurance_Due', '$Tax_Validity', '$Fitness_Due', '$PUC_Due')";

		if($conn->query($sql)){
			$_SESSION['success'] = 'User added successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	else{
		$_SESSION['error'] = 'Fill up the form first';
	}

	header('location: admin.php');

?>