<?php
	session_start();
	include_once('connection.php');

	if(isset($_POST['edit'])){
		$Id = $_POST['Id'];
		$Registration_No = $_POST['Registration_No'];
		$Vehicle_Class = $_POST['Vehicle_Class'];
		$Body_Type = $_POST['Body_Type'];
		$Manufacturer = $_POST['Manufacturer'];
		$Registration_Date = $_POST['Registration_Date'];
		$Insurance_Due = $_POST['Insurance_Due'];
		$Tax_Validity = $_POST['Tax_Validity'];
		$Fitness_Due = $_POST['Fitness_Due'];
		$PUC_Due = $_POST['PUC_Due'];
		$sql = "UPDATE vehicle_data SET Registration_No = '$Registration_No', Vehicle_Class = '$Vehicle_Class', Body_Type = '$Body_Type', Manufacturer = '$Manufacturer', Insurance_Due = '$Insurance_Due', Tax_Validity = '$Tax_Validity', PUC_No = '$PUC_No', Fitness_Due = '$Fitness_Due', PUC_Due = '$PUC_Due' WHERE Id = '$Id'";

		if($conn->query($sql)){
			$_SESSION['success'] = 'User updated successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong in updating User';
		}
	}
	else{
		$_SESSION['error'] = 'Select the user to edit first';
	}

	header('location: admin.php');

?>