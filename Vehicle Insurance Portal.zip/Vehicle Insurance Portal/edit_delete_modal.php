<div class="modal fade" id="edit_<?php echo $row['Id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Edit User</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="edit.php">
				<input type="hidden" class="form-control" name="Id" value="<?php echo $row['Id']; ?>">
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Registration No.</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Registraion_No" value="<?php echo $row['Registration_No']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Vehicle Class</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Vehicle_Class" value="<?php echo $row['Vehicle_Class']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Body Type</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Body_Type" value="<?php echo $row['Body_Type']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Manufacturer</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Manufacturer" value="<?php echo $row['Manufacturer']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Registration Date</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Registration_Date" value="<?php echo $row['Registration_Date']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Fitness Due</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Fitness_Due" value="<?php echo $row['Fitness_Due']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Tax Validity</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Tax_Validity" value="<?php echo $row['Tax_Validity']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Insurance Due</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Insurance_Due" value="<?php echo $row['Insurance_Due']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">PUC Due</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="PUC_Due" value="<?php echo $row['PUC_Due']; ?>">
					</div>
				</div>
            </div> 
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="edit" class="btn btn-success"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="delete_<?php echo $row['Id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="false">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Delete User</h4></center>
            </div>
            <div class="modal-body">	
            	<p class="text-center">Are you sure you want to Delete User ?</p>
				<h2 class="text-center"><?php echo $row['Registration_No'].' ' ?></h2>
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="delete.php?id=<?php echo $row['Id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Yes</a>
            </div>

        </div>
    </div>
</div>